<?php 
    session_start(); 
    if (isset($_SESSION['id'])){
        $m = $_SESSION['id'];
    session_id($m);
    }

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
        header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="assets/css/main.css" />
<link rel="icon" type="image/png" href="/Logo.png">

<style>
div.container {
    width: 100%;
    border: 1px solid gray;
}

header, footer {
    padding: 1em;
    color: white;
    background-color: #723a806b;
    clear: left;
    text-align: center;
    border: 2px ;
    border-radius: 8px;
}

nav {
    float: left;
    max-width: 160px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
    padding: 0;
}
   
nav ul a {
    text-decoration: none;
}

article {
    margin-left: 230px;
    border-left: 1px solid gray;
    padding: 1em;
    overflow: hidden;
}
b {
    
    font-size: 20px;
    color:#ffffff;
}
</style>
</head>
<body>
<style>
.button {
    background-color: #555555; 
    border: none;
    color: white;
    padding: 0px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 11px;
    margin: 2px 1px;
    cursor: pointer;
}

.button1 {border-radius: 2px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 8px;}
.button4 {border-radius: 12px;}
.button5 {border-radius: 50%;}
</style>

<button class="button button5" onclick="goBack()">Back</button>
		<script>
				function goBack() {
					window.history.back();
				}
                </script>
<div class="header">
	</div>
	<div class="content">
	<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						// echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>

<div class="container">

<header>
   <h1>Settings</h1>
</header>
  
<nav>
  <ul>
    <li><h2>Welcome</h2></li>
    <li><h2>User</h2></li>
  </ul>
</nav>

<article>
<?php  if (isset($_SESSION['username'])) : ?>
            <p><b>UserName:</b> <strong><?php echo $_SESSION['username']; ?></strong></p>
            <p><b>Vehicle Name:</b> <?php echo $_SESSION['VehName']; ?></p>
            <!-- <p><b>Distance Traveled: </b></p> -->
            <div class="input-group">
			<p><button onclick="location.href= 'about.php'">About</button>
			<p><button> <a onclick="logout()" style="color: red;">Logout</a></button> </p>
		<?php endif ?>
</article>
<script>
					function logout(){
						var r= confirm("Do you want to logout");
						if(r==true){
							window.location.assign("index.php?logout='1'");
						}
					}
					</script>
<footer>PIMO</footer>

</div>

</body>
</html>