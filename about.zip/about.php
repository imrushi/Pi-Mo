
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ABOUT</title>
    <link rel="stylesheet" href="assets/css/main.css" />
    <link rel="icon" type="image/png" href="/Logo.png">

</head>
<body>

                
                <style>
.button {
    background-color: #555555; 
    border: none;
    color: white;
    padding: 0px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 11px;
    margin: 2px 1px;
    cursor: pointer;
}

.button1 {border-radius: 2px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 8px;}
.button4 {border-radius: 12px;}
.button5 {border-radius: 50%;}
</style>

<button class="button button5" onclick="goBack()">Back</button>
		<script>
				function goBack() {
					window.history.back();
				}
                </script>

    <center><h1>PI-MO</h1></center>
    <p>
    This Device is one of its kind and such type device has yet not been used officially
anywhere it has many new and useful features which are very useful for a driver and
can cause less distraction while driving i.e. removing your smartphone for attaining
calls or getting directions for a location there are more useful features like:    
    <li> Listening Music.</li>
 <li>Location tracking of moped.</li>
 <li> Synchronise data with server.</li>
 <li>Connectivity – Bluetooth, WIFI, USB.</li>
 <li>Google Maps.</li>
 <li>Speed over exceed limitation message/warning.</li>
 <li>Smart meter which show the speed.</li>
 <li>Pi Assistant.</li>
 <li>Speed, Distance and Time Logs save on server.</li>
 <li>Eco friendly.</li>
 <li>No extra power supply needed.</li>
 <li>Special account for separate user</li></p>
    <center><h2>Developers</h2>   
    <li>Jefin Francis</li> 
    <li>Rushi Panchariya</li>
    <li>Pushkaraj Sonawane</li>
    <li>Shubham Khatal</li></center>


</body>
</html>